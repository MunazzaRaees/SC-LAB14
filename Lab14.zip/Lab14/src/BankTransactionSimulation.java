import java.util.concurrent.atomic.AtomicInteger;

public class BankTransactionSimulation {
    private static AtomicInteger balance = new AtomicInteger(1000); // Starting balance

    // Method to simulate deposit
    private static void deposit(int amount) {
        balance.addAndGet(amount);
        System.out.println("Deposited: " + amount + " New Balance: " + balance.get());
    }

    // Method to simulate withdrawal
    private static void withdraw(int amount) {
        if (balance.get() >= amount) {
            balance.addAndGet(-amount);
            System.out.println("Withdrew: " + amount + " New Balance: " + balance.get());
        } else {
            System.out.println("Insufficient funds for withdrawal of: " + amount);
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Runnable clientTask = new Runnable() {
            @Override
            public void run() {
                // Simulate random deposits and withdrawals
                for (int i = 0; i < 10; i++) {
                    if (Math.random() > 0.5) {
                        deposit((int)(Math.random() * 100)); // Random deposit
                    } else {
                        withdraw((int)(Math.random() * 100)); // Random withdrawal
                    }
                    try {
                        Thread.sleep(100); // Simulate delay
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        };

        // Create multiple client threads
        Thread client1 = new Thread(clientTask);
        Thread client2 = new Thread(clientTask);
        Thread client3 = new Thread(clientTask);

        // Start client threads
        client1.start();
        client2.start();
        client3.start();

        // Wait for all threads to finish
        client1.join();
        client2.join();
        client3.join();

        // Final balance after all transactions
        System.out.println("Final Balance: " + balance.get());
    }
}
