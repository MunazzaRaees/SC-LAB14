public class MultithreadingTask1 {
    public static void main(String[] args) {
        // Thread to print numbers from 1 to 10
        Runnable printNumbers = new Runnable() {
            @Override
            public void run() {
                for (int i = 1; i <= 10; i++) {
                    System.out.println("Number: " + i);
                    try {
                        Thread.sleep(100); // Pause to see the concurrency
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        };

        // Thread to print squares of numbers from 1 to 10
        Runnable printSquares = new Runnable() {
            @Override
            public void run() {
                for (int i = 1; i <= 10; i++) {
                    System.out.println("Square of " + i + ": " + (i * i));
                    try {
                        Thread.sleep(100); // Pause to see the concurrency
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        };

        // Create threads
        Thread thread1 = new Thread(printNumbers);
        Thread thread2 = new Thread(printSquares);

        // Start threads concurrently
        thread1.start();
        thread2.start();
    }
}
