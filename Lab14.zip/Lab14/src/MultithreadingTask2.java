public class MultithreadingTask2 {
    private static int counter = 0;

    public static void main(String[] args) throws InterruptedException {
        // Define three threads
        Thread thread1 = new Thread(new CounterTask());
        Thread thread2 = new Thread(new CounterTask());
        Thread thread3 = new Thread(new CounterTask());

        // Start the threads
        thread1.start();
        thread2.start();
        thread3.start();

        // Wait for all threads to finish
        thread1.join();
        thread2.join();
        thread3.join();

        // Print the final value of the counter
        System.out.println("Final counter value: " + counter);
    }

    // Task for incrementing the counter 100 times
    private static class CounterTask implements Runnable {
        @Override
        public void run() {
            for (int i = 0; i < 100; i++) {
                incrementCounter();
            }
        }
    }

    // Synchronized method to safely increment the counter
    private synchronized static void incrementCounter() {
        counter++;
    }
}
