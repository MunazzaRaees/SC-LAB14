import java.util.concurrent.CopyOnWriteArrayList;

public class MultithreadingTask3 {
    public static void main(String[] args) throws InterruptedException {
        // Create a thread-safe CopyOnWriteArrayList
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();

        Runnable addElements = new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    list.add(i);
                    System.out.println("Added: " + i);
                }
            }
        };

        Runnable printElements = new Runnable() {
            @Override
            public void run() {
                for (Integer i : list) {
                    System.out.println("Reading: " + i);
                    try {
                        Thread.sleep(50); // Simulate delay
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        };

        // Create threads
        Thread writerThread = new Thread(addElements);
        Thread readerThread = new Thread(printElements);

        // Start threads
        writerThread.start();
        readerThread.start();

        // Wait for both threads to finish
        writerThread.join();
        readerThread.join();
    }
}
